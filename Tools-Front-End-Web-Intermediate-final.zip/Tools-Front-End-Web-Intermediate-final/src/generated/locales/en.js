// Do not modify this file by hand!
// Re-generate this file by running lit-localize

import { html } from 'lit'

/* eslint-disable no-irregular-whitespace */
/* eslint-disable @typescript-eslint/no-explicit-any */

export const templates = {
  hd0737f87443a52a2: html`
    Story App is an application created with the aim of facilitating users to share their stories
    and experiences in a creative and meaningful way. The app It dedicates itself to bringing
    unforgettable stories to life and making meaning in every moment. realizing the meaning in every
    moment. With the Story App, users can share life journeys, achievements, and even simple events
    that have deep meaning in their lives. in their lives. It is a platform that allows them to
    store memories, empathize with others' experiences, and celebrate creativity in the form of
    diverse visual narratives. in the form of diverse visual narratives. From beautiful photos to
    inspirational writings inspirational writings, Story App presents a platform that unites people
    from different backgrounds, making every experience precious and backgrounds, making every
    experience worthwhile and every story meaningful. meaningful. With the Story App, our world is
    given the opportunity to speak through inspiring images, words and emotions, helping us embrace
    the beauty and meaning in every step of our lives. beauty and meaning in every step of our
    lives.
  `,
}
